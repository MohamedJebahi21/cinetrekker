# i18n Coverage Report

Generated: 2026-06-14T16:47:52.913Z

English key count: 1167

| Locale | Key Count | Missing | Status |
| --- | ---: | ---: | --- |
| ar | 1238 | 0 | Pass |
| de | 1227 | 0 | Pass |
| es | 1227 | 0 | Pass |
| fr | 1227 | 0 | Pass |
| tr | 1227 | 0 | Pass |

Total missing keys across locales: 0

All locale files match the English key set. The coverage guard is green.
