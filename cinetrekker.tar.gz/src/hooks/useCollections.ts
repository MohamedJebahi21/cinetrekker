import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { createLogger } from '@/lib/logger';
import type { PostgrestError } from '@supabase/supabase-js';

const logger = createLogger('collections');

export type CollectionsFetchStatus =
  | 'idle'
  | 'ok'
  | 'schema_missing'
  | 'network_error';

interface CollectionsQueryResult {
  items: Array<Record<string, unknown>>;
  fetchStatus: CollectionsFetchStatus;
}

export const useCollections = () => {
  const { user } = useAuth();
  return useQuery({
    queryKey: ['collections', user?.id],
    enabled: !!user,
    queryFn: async (): Promise<CollectionsQueryResult> => {
      if (!user) {
        return { items: [], fetchStatus: 'idle' };
      }
      try {
        const { data, error } = await supabase
          .from('collections')
          .select('id, name, description, created_at, updated_at, user_id, items')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (error) {
          const typedError = error as PostgrestError;
          const errorCode = typedError.code;
          const errorMessage = typedError.message;
          if (errorCode === 'PGRST205' || errorMessage?.includes("Could not find the table")) {
            logger.warn('Collections table missing in Supabase; returning empty list.');
            return { items: [], fetchStatus: 'schema_missing' };
          }
          logger.error('Failed to fetch collections', error);
          return { items: [], fetchStatus: 'network_error' };
        }

        return { items: (data || []) as Array<Record<string, unknown>>, fetchStatus: 'ok' };
      } catch (err) {
        logger.error('Network error fetching collections', err);
        return { items: [], fetchStatus: 'network_error' };
      }
    },
    select: (result) => ({
      data: result.items,
      fetchStatus: result.fetchStatus,
    }),
    staleTime: 1000 * 60 * 5,
  });
};

export const useCreateCollection = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (name: string) => {
      if (!user) throw new Error('Not authenticated');
      const { data, error } = await supabase
        .from('collections')
        .insert({ user_id: user.id, name })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['collections'] }),
    onError: (err) => {
      logger.error('Create collection failed', err);
      toast({ title: 'Error creating collection', variant: 'destructive' });
    }
  });
};

export const useAddToCollection = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (params: { collection_id: number; media_id: number; media_type: 'movie' | 'tv' }) => {
      if (!user) throw new Error('Not authenticated');
      const { error } = await supabase
        .from('collection_items')
        .upsert({ collection_id: params.collection_id, media_id: params.media_id, media_type: params.media_type, added_at: new Date().toISOString() }, { onConflict: 'collection_id,media_id,media_type' });
      if (error) throw error;
      return params;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['collections'] });
      toast({ title: 'Added to collection' });
    },
    onError: (err) => {
      logger.error('Add to collection failed', err);
      toast({ title: 'Error adding to collection', variant: 'destructive' });
    }
  });
};

export const useRemoveFromCollection = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (params: { collection_id: number; media_id: number; media_type: 'movie' | 'tv' }) => {
      if (!user) throw new Error('Not authenticated');
      const { error } = await supabase
        .from('collection_items')
        .delete()
        .eq('collection_id', params.collection_id)
        .eq('media_id', params.media_id)
        .eq('media_type', params.media_type);
      if (error) throw error;
      return params;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['collections'] });
      toast({ title: 'Removed from collection' });
    },
    onError: (err) => {
      logger.error('Remove from collection failed', err);
      toast({ title: 'Error removing from collection', variant: 'destructive' });
    }
  });
};

export const useCollectionItems = (collectionId?: number) => {
  return useQuery({
    queryKey: ['collectionItems', collectionId],
    queryFn: async () => {
      if (!collectionId) return [];
      try {
        const { data, error } = await supabase
          .from('collection_items')
          .select('media_id, media_type')
          .eq('collection_id', collectionId);

        if (error) {
          logger.error('Failed to fetch collection items', error);
          return [];
        }

        return (data || []).map((d: { media_id: number; media_type: string }) => ({ mediaId: d.media_id, mediaType: d.media_type }));
      } catch (err) {
        logger.error('Network error fetching collection items', err);
        return [];
      }
    },
    enabled: !!collectionId,
    staleTime: 1000 * 60 * 5,
  });
};

export default useCollections;
